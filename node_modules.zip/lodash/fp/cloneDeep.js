var convert = require('./convert'),
    func = convert('cloneDeep', require('../cloneDeep'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
