var convert = require('./convert'),
    func = convert('cloneWith', require('../cloneWith'));

func.placeholder = require('./placeholder');
module.exports = func;
